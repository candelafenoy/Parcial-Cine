---
name: CineTrack Noir
colors:
  surface: '#111319'
  surface-dim: '#111319'
  surface-bright: '#373940'
  surface-container-lowest: '#0c0e14'
  surface-container-low: '#191b22'
  surface-container: '#1e1f26'
  surface-container-high: '#282a30'
  surface-container-highest: '#33343b'
  on-surface: '#e2e2eb'
  on-surface-variant: '#e5bdc0'
  inverse-surface: '#e2e2eb'
  inverse-on-surface: '#2e3037'
  outline: '#ac888b'
  outline-variant: '#5c3f42'
  surface-tint: '#ffb2ba'
  primary: '#ffb2ba'
  on-primary: '#670020'
  primary-container: '#ff4f73'
  on-primary-container: '#5a001b'
  inverse-primary: '#bd0042'
  secondary: '#dcfdff'
  on-secondary: '#00373a'
  secondary-container: '#00f1fd'
  on-secondary-container: '#006a6f'
  tertiary: '#edc157'
  on-tertiary: '#3f2e00'
  tertiary-container: '#b28b26'
  on-tertiary-container: '#372700'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffd9dc'
  primary-fixed-dim: '#ffb2ba'
  on-primary-fixed: '#400011'
  on-primary-fixed-variant: '#910030'
  secondary-fixed: '#6ff6ff'
  secondary-fixed-dim: '#00dce6'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f53'
  tertiary-fixed: '#ffdf9b'
  tertiary-fixed-dim: '#edc157'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5b4300'
  background: '#111319'
  on-background: '#e2e2eb'
  surface-variant: '#33343b'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-telemetry:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-badge:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-rating:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies the darkroom intimacy of an arthouse screening theater fused with bleeding-edge cyberpunk neo-noir telemetry. It caters to cinephiles, festival programmers, critical curators, and film obsessives who view movie tracking as both an aesthetic ritual and an analytical passion.

The mood balances deep OLED darkness with neon chromatic aberration. The backdrop is inky, obsidian, and non-distracting, allowing cinematic key art, film stills, and posters to command primary focus. High-chroma electric accents—hot pink/coral red, laser cyan, and golden star yellow—serve as focused points of illumination, reminiscent of 35mm projection lamps cutting through haze, neon-drenched marquee signs, and projection booth monitors.

The style marries glassmorphism with tactile digital instrumentation:
- Deep tiered translucent cards with delicate frosted blur surfaces (`backdrop-filter: blur(16px)`).
- Ultra-crisp hairline inner borders simulating edge-lit glass panels.
- Micro-pill badges with luminescent status dots mimicking tally lights on 35mm Panavision rigs.
- Monospaced technical telemetry readouts (aspect ratios, runtimes, sync IDs) paired with punchy modern sans-serif headlines.

## Colors

The palette relies on absolute darkness layered over subtly tinted midnight blues, punctured by hyper-saturated theatrical accents.

### Palette Architecture
- **Primary Accent (`#ff3366` - Cine Neon Rose):** The marquee signal. Used for primary calls to action, high-ranking film status indicators, favorite heart triggers, tier-S markers, and critical review ratings.
- **Secondary Accent (`#00f2fe` - Electric 35mm Cyan):** The projection beam. Used for live session states, verification ticks, encrypted system badges, technical tags, and secondary metric bars.
- **Tertiary Accent (`#ffd166` - Star Vault Gold):** The award laurel. Used exclusively for ratings (10/10), top-tier star symbols, curation highlights, and festival laurel badges.
- **Base Canvas (`#0c0e14` - OLED Void):** Pure darkroom backdrop optimized for deep contrast and zero visual fatigue.
- **Surface Elevation 1 (`#12151f` - Noir Hull):** Container panels, modal drawers, table rows, and card backgrounds.
- **Surface Elevation 2 (`#1a1e2d` - Projection Slate):** Interactive card hovers, inset input fields, and pill switch tracks.
- **Hairline Border Tints:** Subtle cyan-tinted borders (`rgba(0, 242, 254, 0.15)`) and rose-tinted glow borders (`rgba(255, 51, 102, 0.25)`).

### Contrast & State Rules
Text elements default to `#f4f6fb` (Pure Marquee White) for titles and `#8b94a8` (Slate Fog) for metadata and runtimes. Active states emit soft ambient halos using a 12px blur at 30% alpha of the corresponding neon hue.

## Typography

The typographic hierarchy blends structured geometric architecture with precise machine telemetry:
- **Headline Engine (Space Grotesk):** Gives film titles, profile headings, and hero metrics an angular, cinematic posture with distinct brutalist flair.
- **Body Engine (Hanken Grotesk):** Provides frictionless editorial legibility across long film synopses, user reviews, and director notes in low-light environments.
- **Telemetry & Metadata Engine (JetBrains Mono):** Formats year of release, theatrical aspect ratios, runtimes (`2h 46m`), ranking indicators (`#01`, `#18`), and user encryption tags (`ID: #CT-80492`). It introduces technical precision to editorial workflows.

Letter-spacing is tightened on display headers (`-0.02em`) to echo movie poster billing blocks, while mono labels receive uppercase tracking (`0.08em`) to mimic raw film edge codes.

## Layout & Spacing

This design system uses a rhythmic layout framework calibrated for content density and visual pacing.

### Structural Grid Architecture
- **Desktop (1200px+):** A 12-column fluid grid framed within a maximum container width of `1380px`. Gutters sit at `1.5rem` (`24px`) with outer canvas margins at `3rem` (`48px`). Catalog layouts flex between a 5-column poster grid and a 2-column detailed telemetry list.
- **Tablet (768px – 1199px):** An 8-column layout with `1rem` (`16px`) gutters and `1.5rem` (`24px`) margins. Poster grids shift to 3 columns.
- **Mobile (< 768px):** A single column or 2-column poster grid using `1rem` outer canvas padding and compact vertical gaps (`0.75rem` - `1rem`) for smooth one-thumb skimming.

### Spatial Rhythm
The core unit is a 4px base increment. 
- `space-xs` (4px) separates icon glyphs from label counts.
- `space-sm` (8px) pads micro badges and sets internal poster metadata margins.
- `space-md` (12px) structures card internal paddings and input interior offsets.
- `space-lg` (20px) governs intra-card spacing in stacked feeds.
- `space-xl` (32px) acts as the section divider across collection shelves and curation lists.

## Elevation & Depth

Visual hierarchy avoids generic drop shadows, utilizing stacked darkroom luminescent panels, selective glass refraction, and inner neon perimeter lights.

### 1. Tonal Layers (Backdrop to Foreground)
- **Base Canvas Level 0 (`#0c0e14`):** Raw deep screen floor.
- **Container Level 1 (`#12151f` with 0.85 opacity):** Frosted glass panels layered with `backdrop-filter: blur(16px)`.
- **Card Elevated Level 2 (`#1a1e2d`):** Interactive blocks, hovering film items, and active stat counters.

### 2. Glassmorphic Borders & Rim Lighting
Every floating card features a 1px border. Default states use a muted slate-cyan rim: `border: 1px solid rgba(255, 255, 255, 0.07)`. 
When a container holds an active or top-ranked asset, the border transitions to a directional gradient: `linear-gradient(135deg, rgba(255, 51, 102, 0.4) 0%, rgba(0, 242, 254, 0.1) 100%)`.

### 3. Glow Metrics (Ambient Projection Shading)
Interactive elements receive concentrated neon glows rather than heavy black drop shadows:
- **Primary Interactive Glow:** `box-shadow: 0 4px 20px -2px rgba(255, 51, 102, 0.35)`
- **Secondary Active Halo:** `box-shadow: 0 0 14px 1px rgba(0, 242, 254, 0.25)`
- **Gold Star Bloom:** `text-shadow: 0 0 8px rgba(255, 209, 102, 0.5)`

## Shapes

The geometric framework balances clean modern cards with pill-shaped control elements:

- **Base Cards & Modals:** Built with `rounded-lg` (`1rem` / `16px`) to present movie posters and stats as tactile, pocket-sized vitrines.
- **Film Posters:** Fitted with `0.5rem` (`8px`) corner radiuses, maintaining crisp structural contours while softening outer boundaries.
- **Buttons, Filter Chips, Badges & Tally Bullets:** Employ full circular pill caps (`border-radius: 9999px`) to create an organic, tactile contrast against rectilinear poster artwork.
- **Inset Fields & Metrics Blocks:** Standardized at `0.5rem` (`8px`) for compact instrumentation screens.

## Components

### Buttons
- **Primary Hero Button:** Pill-shaped (`border-radius: 9999px`), vivid Cine Neon Rose gradient (`linear-gradient(135deg, #ff3366 0%, #e02456 100%)`), crisp white text in Space Grotesk Bold, with a soft neon bloom (`0 4px 16px rgba(255, 51, 102, 0.35)`).
- **Secondary Action Button:** Deep slate fill (`#1a1e2d`), 1px hairline border (`rgba(255, 255, 255, 0.1)`), neutral white typography, subtle hover scale (`1.02`), and border brightening.
- **Ghost Utility Button:** Monospaced label, transparent fill, 1px border in cyan (`rgba(0, 242, 254, 0.3)`), cyan text on hover with an electric halo.

### Cinephile Chips & Filter Badges
- Fully rounded pills displaying an active tally dot (`w-2 h-2 rounded-full`).
- Inactive state: `#161924` surface with `#8b94a8` text.
- Active state: `#ff3366` surface with `#ffffff` text, or high-contrast outlined variants featuring glowing cyan / coral pips.

### Film Cards (Grid & List View)
- **Grid Poster Card:** Fixed aspect ratio (`2:3`), `rounded-lg` outer border, floating top-left star rating badge (`#12151f` with 0.8 blur + gold star text), top-right heart action button, bottom frosted metadata drawer showing title, year, and technical duration.
- **Ranked Film Row:** Left-aligned rank badge (`#1`, `#2`) using JetBrains Mono in vibrant rose or gold, thumbnail thumbnail art (`1:1.4`), Space Grotesk title, metadata row, quick action buttons (`Ver Ficha`, `Guardar`), and right-hand rating indicator.

### Input Fields & Search Bars
- Inset dark background (`#10131d`), 1px slate-border (`rgba(255, 255, 255, 0.08)`), Space Grotesk/Hanken Grotesk hybrid typing, integrated leading icons (film reel, magnifying glass, clapperboard).
- Focused state transforms the border to an electric cyan glow (`#00f2fe`) with an inner 2px shadow.

### Desktop Navigation Bar
- Frosted top bar (`backdrop-filter: blur(20px)`, `#0c0e14` with 80% opacity), 1px bottom divider line.
- Brand logo: CineTrack Noir with glowing film strip glyph icon.
- Central search input with quick-shortcut key pill (`⌘K`).
- Right-aligned profile chip, notifications bell with neon unread indicator dot, and direct "Sugerir Película" action pill.

### Cinephile Comprehensive Footer
- Cinematic dark container (`#0c0e14`) with a top glowing gradient divider (`1px` height fading from transparent to cyan to rose to transparent).
- 4-column layout: Curated Archives, Database Metrics (TMDb / Letterboxd Sync), Editorial Governance, and API Telemetry status (`API Connection Encrypted TLS 1.3`).
- Bottom row: Monospaced software version badge (`CineTrack v2.4.1 • Cinephile Studio Edition`) and copyright legal block.