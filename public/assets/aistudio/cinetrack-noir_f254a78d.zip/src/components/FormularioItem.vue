<script setup lang="ts">
import FormularioItemComponent from './formularioItem.vue';
</script>

<template>
  <FormularioItemComponent v-bind="$attrs" />
</template>
