<script setup lang="ts">
import NavbarComponent from './navbar.vue';
</script>

<template>
  <NavbarComponent v-bind="$attrs" />
</template>
