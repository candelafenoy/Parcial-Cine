<script setup lang="ts">
import CardItemComponent from './cardItem.vue';
</script>

<template>
  <CardItemComponent v-bind="$attrs" />
</template>
