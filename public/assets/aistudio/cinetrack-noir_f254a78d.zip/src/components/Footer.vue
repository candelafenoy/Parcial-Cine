<script setup lang="ts">
import FooterComponent from './footer.vue';
</script>

<template>
  <FooterComponent v-bind="$attrs" />
</template>
