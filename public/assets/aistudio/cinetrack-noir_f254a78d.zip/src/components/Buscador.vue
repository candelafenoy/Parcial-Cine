<script setup lang="ts">
import BuscadorComponent from './buscador.vue';
</script>

<template>
  <BuscadorComponent v-bind="$attrs" />
</template>
