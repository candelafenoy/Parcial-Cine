export interface Movie {
  id: string;
  title: string;
  originalTitle?: string;
  director: string;
  year: number;
  runtime: string; // e.g. "166 min" or "2h 46m"
  genre: string; // primary genre
  subgenres: string[];
  rating: number; // 0-10
  synopsis: string;
  posterUrl: string;
  bannerUrl?: string;
  isFavorite: boolean;
  status: 'porver' | 'vistas' | 'archivada';
  rankPosition?: number;
  userRating?: number;
  userNotes?: string;
  referenceUrl?: string;
  isSuggested?: boolean;
  curatorName?: string;
  createdAt: string;
}

export interface CommunityReview {
  id: string;
  userName: string;
  userHandle: string;
  userAvatar: string;
  userRole: string;
  movieTitle: string;
  moviePoster: string;
  rating: number;
  reviewText: string;
  likes: number;
  hasLiked?: boolean;
  commentsCount: number;
  timeAgo: string;
  tags: string[];
}

export interface CommunityMember {
  id: string;
  name: string;
  currentMovie: string;
  ratingText: string;
  avatarUrl: string;
  status: 'online' | 'watching' | 'reviewing';
  role: string;
}

export type ViewType = 'catalogo' | 'mi-coleccion' | 'comunidad' | 'sugerir-pelicula' | 'perfil';
